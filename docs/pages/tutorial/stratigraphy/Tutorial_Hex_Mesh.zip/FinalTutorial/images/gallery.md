# Image Gallery 

Gallery written: Fri Aug  9 11:52:13 2019

Image Directory: /project/meshing/demos/Tutorial_Hex_Mesh/images


|  |  |  |   | 
| :---: | :---: | :---: | :---:  | 
|  |  |  |   | 
|  **01_hex_01** |  **02_hex_01_top_region** |  **03_hex_01_2surfs_b** |  **03_hex_01_2surfs**  | 
| <img width="300" src="01_hex_01.png"> | <img width="300" src="02_hex_01_top_region.png"> | <img width="300" src="03_hex_01_2surfs_b.png"> | <img width="300" src="03_hex_01_2surfs.png">  | 
|  **03_hex_01_set_imt_itetclr** |  **03_hex_01_set_imt_itetclr_threshold_remove_material3** |  **05_hex_01_fault_imt_itetclr** |  **06_boundary_truncate**  | 
| <img width="300" src="03_hex_01_set_imt_itetclr.png"> | <img width="300" src="03_hex_01_set_imt_itetclr_threshold_remove_material3.png"> | <img width="300" src="05_hex_01_fault_imt_itetclr.png"> | <img width="300" src="06_boundary_truncate.png">  | 
|  **07_boundary_truncate_fence** |  **08_truncate_set_id** |  **09_truncate_set_id_close_up** |  **10_hex_01_truncate_close_up**  | 
| <img width="300" src="07_boundary_truncate_fence.png"> | <img width="300" src="08_truncate_set_id.png"> | <img width="300" src="09_truncate_set_id_close_up.png"> | <img width="300" src="10_hex_01_truncate_close_up.png">  | 
|  **11_hex_01_truncate** |  **12_hex_01_truncate_w_grid** |  **13_hex_01_fault_refine** |  **14_hex_01_fault_refine_close_up**  | 
| <img width="300" src="11_hex_01_truncate.png"> | <img width="300" src="12_hex_01_truncate_w_grid.png"> | <img width="300" src="13_hex_01_fault_refine.png"> | <img width="300" src="14_hex_01_fault_refine_close_up.png">  | 
|  **15_hex_01_insert_wells** |  **16_hex_01_insert_wells_close_up** |  **17_hex_01_insert_wells_outline** |  **18_hex_01_insert_wells_dfield_wells**  | 
| <img width="300" src="15_hex_01_insert_wells.png"> | <img width="300" src="16_hex_01_insert_wells_close_up.png"> | <img width="300" src="17_hex_01_insert_wells_outline.png"> | <img width="300" src="18_hex_01_insert_wells_dfield_wells.png">  | 
|  **19_hex_01_to_tet** |  **21_tet_01_exo_blocks_ex** |  **21_tet_01_exo_blocks** |  **21_tet_01_exo_bndry_faces**  | 
| <img width="300" src="19_hex_01_to_tet.png"> | <img width="300" src="21_tet_01_exo_blocks_ex.png"> | <img width="300" src="21_tet_01_exo_blocks.png"> | <img width="300" src="21_tet_01_exo_bndry_faces.png">  | 
|  **21_tet_01_fehm_nodes** |  **21_tet_01_fehm_node_zone_rad16** |  **21_tet_01_fehm_node_zone_top** |  **21_tet_01_fehm_tet_a**  | 
| <img width="300" src="21_tet_01_fehm_nodes.png"> | <img width="300" src="21_tet_01_fehm_node_zone_rad16.png"> | <img width="300" src="21_tet_01_fehm_node_zone_top.png"> | <img width="300" src="21_tet_01_fehm_tet_a.png">  | 
|  **21_tet_01_fehm_vor_a** |  **21_tet_01_fehm_voronoi_a** |  **21_tet_01_fehm_voronoi** |  **21_tet_01_fehm_vor_tet_a**  | 
| <img width="300" src="21_tet_01_fehm_vor_a.png"> | <img width="300" src="21_tet_01_fehm_voronoi_a.png"> | <img width="300" src="21_tet_01_fehm_voronoi.png"> | <img width="300" src="21_tet_01_fehm_vor_tet_a.png">  | 


End Gallery
